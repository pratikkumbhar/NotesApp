package com.example.notesapp.Repository;

import com.example.notesapp.Room.Dao;

public class NotesRepository {

    public Dao notesDao;

    

}
